"""
Tests some backend server functions, which are responsible for
'aggiestack server'.
"""
pass